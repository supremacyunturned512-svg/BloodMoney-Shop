'use strict';
const ROLES={PLAYER:0,ADMIN:1,HEAD_ADMIN:2,OWNER:3,CO_OWNER:9};
const ROLE_LABELS={0:'Player',1:'Admin',2:'Head Admin',3:'Owner',9:'Co-Owner'};
const DB={
  get(k){try{return JSON.parse(localStorage.getItem(k));}catch{return null;}},
  set(k,v){localStorage.setItem(k,JSON.stringify(v));},
  del(k){localStorage.removeItem(k);}
};

const UserStore={
  all(){return DB.get('bmrp_users')||{};},
  get(u){return(this.all())[u?.toLowerCase()]||null;},
  save(u){DB.set('bmrp_users',u);},
  create({username,password,ingame='',steam64=''}){
    const users=this.all(),key=username.toLowerCase();
    if(users[key])return{error:'Username already taken.'};
    users[key]={username,password:btoa(password),ingame,steam64,role:ROLES.PLAYER,
      joinDate:new Date().toISOString(),owned:[],orderIds:[]};
    this.save(users);return{ok:true};
  },
  update(username,patch){
    const users=this.all(),key=username.toLowerCase();
    if(!users[key])return false;
    users[key]={...users[key],...patch};this.save(users);return true;
  },
  verify(username,password){const u=this.get(username);return(u&&u.password===btoa(password))?u:null;},
  addOwned(username,k){
    const u=this.get(username);if(!u)return;
    if(!u.owned.includes(k)){u.owned.push(k);this.update(username,{owned:u.owned});}
  }
};

const Session={
  get(){return DB.get('bmrp_session');},
  set(s){DB.set('bmrp_session',s);window._S=s;},
  end(){DB.del('bmrp_session');window._S=null;},
  current(){return window._S||this.get();},
  username(){return this.current()?.username||null;},
  role(){return this.current()?.role??-1;},
  is(r){return this.role()>=r;},
  canAdmin(){return this.is(ROLES.HEAD_ADMIN);},
  isSuperAdmin(){return this.is(ROLES.CO_OWNER);},
  start(username){
    const u=UserStore.get(username);if(!u)return null;
    const s={username:u.username,role:u.role,at:Date.now()};
    this.set(s);return s;
  }
};

const OStatus={PENDING:'Pending',PROCESSING:'Processing',COMPLETED:'Completed',FAILED:'Failed',REFUNDED:'Refunded'};
const DStatus={QUEUED:'Queued',DELIVERED:'Delivered',FAILED:'Failed',MANUAL:'Manual Required'};

const OrderStore={
  all(){return DB.get('bmrp_orders')||[];},
  get(id){return this.all().find(o=>o.id===id)||null;},
  save(o){DB.set('bmrp_orders',o);},
  forUser(u){return this.all().filter(o=>o.username.toLowerCase()===u.toLowerCase());},
  genId(){return'BMRP-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).substring(2,5).toUpperCase();},
  create(username,items,giftSteam64=''){
    const orders=this.all(),user=UserStore.get(username),id=this.genId();
    const total=items.reduce((s,i)=>s+i.price,0);
    const isGift=!!giftSteam64;
    const order={
      id,username,steam64:isGift?giftSteam64:(user?.steam64||''),
      giftSteam64:isGift?giftSteam64:'',isGift,
      items:items.map(i=>({name:i.name,price:i.price,itemKey:i.itemKey})),
      total,paymentMethod:'stripe',paymentStatus:'Awaiting Payment',
      orderStatus:OStatus.PENDING,deliveryStatus:DStatus.QUEUED,
      createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),notes:''
    };
    orders.unshift(order);this.save(orders);
    if(user){const ids=[...(user.orderIds||[])];ids.unshift(id);UserStore.update(username,{orderIds:ids});}
    return order;
  },
  update(id,patch){
    const orders=this.all(),i=orders.findIndex(o=>o.id===id);
    if(i===-1)return false;
    orders[i]={...orders[i],...patch,updatedAt:new Date().toISOString()};
    this.save(orders);return orders[i];
  },
  complete(id){
    const o=this.get(id);if(!o)return false;
    if(!o.isGift){
      o.items.forEach(item=>{
        if(item.itemKey&&!item.itemKey.startsWith('donation'))
          UserStore.addOwned(o.username,item.itemKey);
      });
    }
    SupporterStore.add(o.username,o.total);
    return this.update(id,{paymentStatus:'Paid',orderStatus:OStatus.COMPLETED,
      deliveryStatus:DStatus.DELIVERED,completedAt:new Date().toISOString()});
  },
  search(q){
    q=q.toLowerCase();
    return this.all().filter(o=>
      o.id.toLowerCase().includes(q)||
      o.username.toLowerCase().includes(q)||
      o.items.some(i=>i.name.toLowerCase().includes(q))
    );
  },
  filter(s){if(!s||s==='all')return this.all();return this.all().filter(o=>o.orderStatus===s);}
};

const SupporterStore={
  all(){return DB.get('bmrp_sup')||[];},
  add(username,amount){
    const s=this.all();s.unshift({username,amount,date:new Date().toLocaleDateString()});
    if(s.length>20)s.pop();DB.set('bmrp_sup',s);
  },
  recent(n=5){return this.all().slice(0,n);},
  top(){
    const t={};this.all().forEach(e=>{t[e.username]=(t[e.username]||0)+e.amount;});
    const s=Object.entries(t).sort((a,b)=>b[1]-a[1]);
    return s[0]?{username:s[0][0],total:s[0][1]}:null;
  }
};

const ContentStore={
  all(){return DB.get('bmrp_content')||{};},
  get(k){return this.all()[k]||null;},
  set(k,v){const c=this.all();c[k]=v;DB.set('bmrp_content',c);},
  getPending(){return DB.get('bmrp_cp')||[];},
  submitEdit(key,value,username){
    const p=this.getPending();
    p.push({id:Date.now(),key,value,username,submittedAt:new Date().toISOString(),status:'Pending'});
    DB.set('bmrp_cp',p);
  },
  approveEdit(id){
    const p=this.getPending(),e=p.find(x=>x.id===id);
    if(!e)return;this.set(e.key,e.value);e.status='Approved';DB.set('bmrp_cp',p);
  },
  rejectEdit(id){
    const p=this.getPending(),e=p.find(x=>x.id===id);
    if(!e)return;e.status='Rejected';DB.set('bmrp_cp',p);
  }
};

const SuggestionStore={
  all(){return DB.get('bmrp_sug')||[];},
  add(username,text,type){
    const s=this.all();
    s.unshift({id:Date.now(),username,text,type,createdAt:new Date().toISOString(),status:'Pending'});
    DB.set('bmrp_sug',s);
  },
  updateStatus(id,status){
    const s=this.all(),i=s.findIndex(x=>x.id===id);
    if(i===-1)return;s[i].status=status;DB.set('bmrp_sug',s);
  }
};

const GiftCodeStore={
  all(){return DB.get('bmrp_giftcodes')||[];},
  save(c){DB.set('bmrp_giftcodes',c);},
  generate(itemKey,itemName,createdBy){
    const codes=this.all();
    const code='BMRP-'+Math.random().toString(36).substring(2,6).toUpperCase()+'-'+Math.random().toString(36).substring(2,6).toUpperCase();
    codes.push({code,itemKey,itemName,createdBy,createdAt:new Date().toISOString(),used:false,usedBy:'',usedAt:''});
    this.save(codes);return code;
  },
  redeem(code,username){
    const codes=this.all(),i=codes.findIndex(c=>c.code===code.toUpperCase());
    if(i===-1)return{error:'Invalid gift code.'};
    if(codes[i].used)return{error:'This code has already been used.'};
    codes[i].used=true;codes[i].usedBy=username;codes[i].usedAt=new Date().toISOString();
    this.save(codes);
    UserStore.addOwned(username,codes[i].itemKey);
    return{ok:true,item:codes[i].itemName};
  }
};

const VisitorStore={
  count(){return DB.get('bmrp_vis')||0;},
  track(){
    if(DB.get('bmrp_vid'))return this.count();
    DB.set('bmrp_vid','V-'+Date.now());
    const c=(DB.get('bmrp_vis')||0)+1;DB.set('bmrp_vis',c);return c;
  }
};

window.BMRP={ROLES,ROLE_LABELS,DB,UserStore,Session,OrderStore,OStatus,DStatus,
  SupporterStore,ContentStore,SuggestionStore,GiftCodeStore,VisitorStore};
