'use strict';
const OWNER_STEAM='76561199470988563',ADM_UN='bmrpadmin',ADM_PW='BMRP@Admin2026';
// Stripe publishable key — replace with your real key from stripe.com dashboard
const STRIPE_PK='pk_live_REPLACE_WITH_YOUR_STRIPE_KEY';
const RAILWAY_URL='https://bloodmoneyshop.up.railway.app';

/* ── SEED ADMIN ── */
function seedAdmin(){
  const{UserStore,ROLES}=window.BMRP;
  if(!UserStore.get(ADM_UN)){
    const r=UserStore.create({username:ADM_UN,password:ADM_PW,ingame:'Server Admin',steam64:OWNER_STEAM});
    if(r.ok)UserStore.update(ADM_UN,{role:ROLES.CO_OWNER});
  } else {
    UserStore.update(ADM_UN,{role:ROLES.CO_OWNER});
  }
}

/* ── SCROLL ── */
function initScroll(){
  const b=document.getElementById('sp');if(!b)return;
  window.addEventListener('scroll',()=>{
    const t=document.documentElement.scrollHeight-window.innerHeight;
    b.style.transform=`scaleX(${t>0?window.scrollY/t:0})`;
  },{passive:true});
}

/* ── IP BAR ── */
function initIP(){
  const a=document.getElementById('ip-val'),b=document.getElementById('port-val');
  if(a)a.textContent=window.CFG?.ip||'0.0.0.0';
  if(b)b.textContent=window.CFG?.port||'00000';
}
function copyChip(t){
  const v=t==='ip'?(window.CFG?.ip||'0.0.0.0'):(window.CFG?.port||'00000');
  const el=document.getElementById(t+'-hint');
  const done=()=>{if(!el)return;const o=el.textContent;el.textContent='✓';el.style.color='#2ecc71';setTimeout(()=>{el.textContent=o;el.style.color='';},2000);};
  try{navigator.clipboard.writeText(v).then(done).catch(()=>fbCopy(v,done));}catch{fbCopy(v,done);}
}
function fbCopy(v,cb){
  const e=document.createElement('textarea');e.value=v;e.style.cssText='position:fixed;opacity:0';
  document.body.appendChild(e);e.select();document.execCommand('copy');document.body.removeChild(e);if(cb)cb();
}

/* ── MOBILE NAV — clean, no conflicts ── */
function initNav(){
  const ham=document.getElementById('nav-ham');
  const links=document.getElementById('nav-links');
  if(!ham||!links)return;
  ham.addEventListener('click',function(e){
    e.stopPropagation();
    const open=links.classList.toggle('open');
    ham.innerHTML=open?'✕':'☰';
  });
  links.querySelectorAll('a,button').forEach(el=>{
    el.addEventListener('click',()=>{
      links.classList.remove('open');
      ham.innerHTML='☰';
    });
  });
  document.addEventListener('click',function(e){
    if(links.classList.contains('open')&&!links.contains(e.target)&&!ham.contains(e.target)){
      links.classList.remove('open');ham.innerHTML='☰';
    }
  },{passive:true});
}

/* ── NAV STATE ── */
function applyNav(){
  const{Session,UserStore,ROLES}=window.BMRP;
  const s=Session.current();
  const lb=document.getElementById('nav-login-label');
  if(lb)lb.textContent=s?s.username:'Login';
  const al=document.getElementById('nav-admin');
  if(al){
    if(s&&s.role>=ROLES.CO_OWNER){
      const u=UserStore.get(s.username);
      al.style.display=(u&&u.steam64===OWNER_STEAM)?'inline-flex':'none';
    } else al.style.display='none';
  }
  updateBadge();
  renderSupporters();
  initAdminPanel();
}

/* ── OVERLAYS ── */
function openOv(id){
  const e=document.getElementById(id);
  if(e){e.style.display='flex';document.body.style.overflow='hidden';}
}
function closeOv(id){
  const e=document.getElementById(id);if(e)e.style.display='none';
  const any=document.querySelector('.bmrp-ov[style*="flex"]');
  if(!any)document.body.style.overflow='';
}
function closeBg(e,id){if(e.target===e.currentTarget)closeOv(id);}

/* ── ALERT ── */
function showAlert(icon,title,msg,onOk){
  const o=document.getElementById('alert-ov');
  if(!o){alert(msg);if(onOk)onOk();return;}
  o.querySelector('.al-ico').textContent=icon;
  o.querySelector('.al-ttl').textContent=title;
  o.querySelector('.al-msg').textContent=msg;
  const b=o.querySelector('.al-ok');
  b.onclick=()=>{closeOv('alert-ov');if(onOk)onOk();};
  openOv('alert-ov');
}

/* ── AUTH ── */
function openLoginModal(){
  const{Session}=window.BMRP;
  if(Session.current()){openAccountModal();return;}
  switchTab('auth','login');
  clearAuthErr();
  openOv('auth-ov');
}
function closeLoginModal(){closeOv('auth-ov');clearAuthErr();}
function clearAuthErr(){const e=document.getElementById('auth-err');if(e){e.textContent='';e.style.display='none';}}

function handleLogin(e){
  e?.preventDefault();
  const{UserStore,Session}=window.BMRP;
  const u=(document.getElementById('l-user')?.value||'').trim();
  const p=document.getElementById('l-pass')?.value||'';
  if(!u||!p){showAuthErr('Enter your username and password.');return;}
  if(u.toLowerCase()===ADM_UN){
    const usr=UserStore.get(u);
    if(usr&&usr.steam64&&usr.steam64!==OWNER_STEAM){showAuthErr('Access denied.');return;}
  }
  const user=UserStore.verify(u,p);
  if(!user){showAuthErr('Incorrect username or password.');return;}
  Session.start(u);closeLoginModal();applyNav();openWelcome();
}

function handleRegister(e){
  e?.preventDefault();
  const{UserStore,Session}=window.BMRP;
  const username=(document.getElementById('r-user')?.value||'').trim();
  const ingame=(document.getElementById('r-ingame')?.value||'').trim();
  const password=document.getElementById('r-pass')?.value||'';
  const confirm=document.getElementById('r-conf')?.value||'';
  if(!username||!ingame||!password||!confirm){showAuthErr('Please fill out all fields.');return;}
  if(password!==confirm){showAuthErr('Passwords do not match.');return;}
  if(password.length<6){showAuthErr('Password must be at least 6 characters.');return;}
  if(!/^[a-zA-Z0-9_]{3,20}$/.test(username)){showAuthErr('Username: 3-20 chars, letters/numbers/underscores only.');return;}
  if(username.toLowerCase()===ADM_UN){showAuthErr('That username is reserved.');return;}
  const r=UserStore.create({username,ingame,password});
  if(r.error){showAuthErr(r.error);return;}
  Session.start(username);closeLoginModal();applyNav();openWelcome();
}

function handleLogout(){window.BMRP.Session.end();closeOv('account-ov');applyNav();}
function showAuthErr(msg){const e=document.getElementById('auth-err');if(e){e.textContent=msg;e.style.display='block';}}

function handleChangePassword(e){
  e?.preventDefault();
  const{UserStore,Session}=window.BMRP;
  const s=Session.current();if(!s)return;
  const cur=document.getElementById('cp-cur')?.value||'';
  const nw=document.getElementById('cp-new')?.value||'';
  const cf=document.getElementById('cp-cf')?.value||'';
  const m=document.getElementById('cp-msg');
  const show=(t,ok)=>{if(m){m.textContent=t;m.style.color=ok?'#2ecc71':'#ff6666';m.style.display='block';setTimeout(()=>m.style.display='none',4000);}};
  if(!cur||!nw||!cf){show('Fill out all fields.',false);return;}
  if(nw!==cf){show('Passwords do not match.',false);return;}
  if(nw.length<6){show('Min 6 characters.',false);return;}
  if(!UserStore.verify(s.username,cur)){show('Current password incorrect.',false);return;}
  UserStore.update(s.username,{password:btoa(nw)});
  show('✓ Password updated!',true);
  ['cp-cur','cp-new','cp-cf'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
}

function saveSteam64(){
  const{Session,UserStore}=window.BMRP;
  const s=Session.current();if(!s)return;
  const val=(document.getElementById('steam-inp')?.value||'').trim();
  const m=document.getElementById('steam-msg');
  const show=(t,ok)=>{if(m){m.textContent=t;m.style.color=ok?'#2ecc71':'#ff6666';m.style.display='block';setTimeout(()=>m.style.display='none',3500);}};
  if(!val){show('Enter a Steam64 ID.',false);return;}
  if(!/^7656119\d{10}$/.test(val)){show('Invalid — 17 digits starting with 7656119.',false);return;}
  UserStore.update(s.username,{steam64:val});
  show('✓ Steam64 saved!',true);
  const el=document.getElementById('acct-steam64');if(el)el.textContent=val;
  applyNav();
}

/* ── GIFT CODE REDEEM ── */
function redeemGiftCode(){
  const{Session,GiftCodeStore}=window.BMRP;
  const s=Session.current();
  if(!s){showAlert('🔒','Login Required','Log in to redeem a gift code.',openLoginModal);return;}
  const inp=document.getElementById('gift-code-inp');
  const code=(inp?.value||'').trim().toUpperCase();
  const m=document.getElementById('gift-code-msg');
  const show=(t,ok)=>{if(m){m.textContent=t;m.style.color=ok?'#2ecc71':'#ff6666';m.style.display='block';setTimeout(()=>m.style.display='none',5000);}};
  if(!code){show('Enter a gift code.',false);return;}
  const r=GiftCodeStore.redeem(code,s.username);
  if(r.error){show('✕ '+r.error,false);return;}
  show('✓ Redeemed! '+r.item+' has been added to your account.',true);
  if(inp)inp.value='';
}

/* ── ACCOUNT MODAL ── */
function openAccountModal(){
  const{Session,UserStore,OrderStore}=window.BMRP;
  const s=Session.current();if(!s){openLoginModal();return;}
  const u=UserStore.get(s.username);
  const orders=OrderStore.forUser(s.username);
  setText('acct-name',u?.username||'');
  setText('acct-role',window.BMRP.ROLE_LABELS[s.role]||'Player');
  setText('acct-ingame',u?.ingame||'—');
  setText('acct-join',u?new Date(u.joinDate).toLocaleDateString():'');
  setText('acct-owned',u?.owned?.length?u.owned.join(', ').toUpperCase():'None yet');
  setText('acct-steam64',u?.steam64||'Not set');
  const si=document.getElementById('steam-inp');if(si&&u?.steam64)si.value=u.steam64;
  const log=document.getElementById('purchase-log');
  if(log){
    if(!orders.length){
      log.innerHTML='<p style="color:#555;text-align:center;padding:16px;font-size:13px">No purchases yet.</p>';
    } else {
      log.innerHTML='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:12px"><thead><tr>'+
        ['Order ID','Items','Total','Status','Type','Date'].map(h=>`<th style="background:#0a0a0a;padding:7px 9px;text-align:left;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#555;border-bottom:1px solid #1f1f1f">${h}</th>`).join('')+
        '</tr></thead><tbody>'+
        orders.map(o=>`<tr onclick="viewOrder('${o.id}')" style="cursor:pointer">
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f;font-size:10px;color:#C8A040">${o.id}</td>
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f;font-size:11px">${o.items.map(i=>i.name).join('<br>')}</td>
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f;font-family:Oswald,sans-serif">$${o.total.toFixed(2)}</td>
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f"><span class="pill ${pillCls(o.orderStatus)}">${o.orderStatus}</span></td>
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f;font-size:10px;color:${o.isGift?'#C8A040':'#555'}">${o.isGift?'🎁 Gift':'Personal'}</td>
          <td style="padding:8px 9px;border-bottom:1px solid #0f0f0f;font-size:10px;color:#555">${new Date(o.createdAt).toLocaleDateString()}</td>
        </tr>`).join('')+'</tbody></table></div>';
    }
  }
  switchTab('acct','profile');openOv('account-ov');
}
function closeAccountModal(){closeOv('account-ov');}
function viewOrder(id){const o=window.BMRP.OrderStore.get(id);if(!o)return;closeOv('account-ov');showConfirm(o);}
function openWelcome(){setText('welcome-name',window.BMRP.Session.current()?.username||'Player');openOv('welcome-ov');}
function closeWelcome(){closeOv('welcome-ov');}

/* ── TABS ── */
function switchTab(group,tab){
  document.querySelectorAll('[data-tg="'+group+'"]').forEach(el=>{
    const match=el.dataset.t===tab;
    if(el.classList.contains('tab-btn'))el.classList.toggle('tb-active',match);
    if(el.classList.contains('tab-panel')){el.style.display=match?'block':'none';el.classList.toggle('tp-active',match);}
  });
}

/* ── CART ── */
let _cart=[];
function updateBadge(){const e=document.getElementById('cart-badge');if(e)e.textContent=_cart.length;}
function openCart(){renderCart();openOv('cart-ov');}

function addToCart(name,price,itemKey,_u,requiresKey){
  const{Session,UserStore}=window.BMRP;
  const username=Session.username();
  if(!username){showAlert('🔒','Login Required','Please log in or create an account before adding items to your cart.',openLoginModal);return;}
  const u=UserStore.get(username);
  if(itemKey&&!itemKey.startsWith('donation')&&u?.owned?.includes(itemKey)){
    showAlert('✋','Already Owned','You already own this item. Each item can only be purchased once per account.');return;
  }
  if(requiresKey&&!u?.owned?.includes(requiresKey)){
    const nm={'vip':'VIP','vip-plus':'VIP+','mvp':'MVP','vault-15':'15-Slot Vault','vault-20':'20-Slot Vault','vault-25':'25-Slot Vault'};
    showAlert('⚠️','Rank Required','You need '+(nm[requiresKey]||requiresKey)+' before purchasing this upgrade.');return;
  }
  if(_cart.find(i=>i.itemKey===itemKey)){showAlert('🛒','Already in Cart','This item is already in your cart.');return;}
  _cart.push({id:Date.now()+Math.random(),name,price,itemKey,requiresKey});
  updateBadge();openCart();
}

function addDonation(){
  const inp=document.getElementById('donate-inp');
  const amount=parseFloat(inp?.value||'0');
  if(!amount||amount<1){showAlert('⚠️','Invalid Amount','Please enter at least $1.');return;}
  if(!window.BMRP.Session.username()){showAlert('🔒','Login Required','Please log in before donating.',openLoginModal);return;}
  _cart.push({id:Date.now(),name:'Donation ($'+amount.toFixed(2)+')',price:amount,itemKey:'donation-'+Date.now(),requiresKey:null});
  updateBadge();if(inp)inp.value='';openCart();
}

function cartRemove(id){_cart=_cart.filter(i=>i.id!==id);updateBadge();renderCart();}

function renderCart(){
  const body=document.getElementById('cart-items'),foot=document.getElementById('cart-foot');
  if(!body)return;
  if(!_cart.length){
    body.innerHTML='<p style="text-align:center;color:#555;padding:28px;font-size:13px">Your cart is empty.</p>';
    if(foot)foot.style.display='none';return;
  }
  body.innerHTML=_cart.map(i=>`
    <div style="display:flex;justify-content:space-between;align-items:center;padding:11px 0;border-bottom:1px solid #161616;gap:10px">
      <span style="font-family:Oswald,sans-serif;font-size:13px;color:#fff">${i.name}</span>
      <span style="display:flex;align-items:center;gap:8px;flex-shrink:0">
        <span style="font-family:Oswald,sans-serif;font-size:13px;color:#7B68EE;font-weight:700">$${i.price.toFixed(2)}</span>
        <button onclick="cartRemove(${i.id})" style="background:none;border:none;color:#444;cursor:pointer;font-size:14px;padding:0 3px;line-height:1">✕</button>
      </span>
    </div>`).join('');
  if(foot){
    foot.style.display='flex';
    const t=document.getElementById('cart-total');
    if(t)t.textContent='$'+_cart.reduce((s,i)=>s+i.price,0).toFixed(2);
  }
}

/* ── CHECKOUT FLOW ── */
function proceedToPayment(){
  if(!_cart.length)return;
  const total=_cart.reduce((s,i)=>s+i.price,0);
  const body=document.getElementById('review-body');
  if(body){
    body.innerHTML=`
      <div style="margin-bottom:16px">
        <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#8B0000;text-transform:uppercase;margin-bottom:8px">Your Order</div>
        ${_cart.map(i=>`<div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #111;font-size:13px"><span>${i.name}</span><span style="color:#7B68EE;font-family:Oswald,sans-serif">$${i.price.toFixed(2)}</span></div>`).join('')}
        <div style="display:flex;justify-content:space-between;padding:12px 0 0;font-family:Oswald,sans-serif;font-size:18px;font-weight:700;color:#fff"><span>Total</span><span>$${total.toFixed(2)}</span></div>
      </div>

      <div style="margin-bottom:14px">
        <div style="font-family:Oswald,sans-serif;font-size:10px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:8px">Purchase Type</div>
        <select id="purchase-type" onchange="toggleGiftField()" style="width:100%;background:#080808;border:1px solid #222;border-radius:3px;padding:10px 12px;color:#fff;font-size:14px;outline:none;font-family:'Roboto Condensed',sans-serif">
          <option value="self">🧍 Purchase for myself</option>
          <option value="gift">🎁 Purchase as a gift for a friend</option>
        </select>
      </div>

      <div id="gift-field" style="display:none;margin-bottom:14px">
        <div style="font-family:Oswald,sans-serif;font-size:10px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:6px">Recipient's Steam64 ID</div>
        <input id="gift-steam64" type="text" maxlength="17" placeholder="76561198000000000"
          style="width:100%;background:#080808;border:1px solid #222;border-radius:3px;padding:10px 12px;color:#fff;font-size:14px;outline:none;font-family:monospace">
        <div style="font-size:11px;color:#444;margin-top:5px">17-digit Steam ID of the player you're gifting to. The item will be delivered to their account.</div>
      </div>

      <div style="background:#0d0d12;border-left:3px solid #7B68EE;padding:11px 13px;font-size:12px;color:#777;line-height:1.7;border-radius:2px">
        💳 Payment is processed securely via <strong style="color:#fff">Stripe</strong>. We never store your card details.
      </div>`;
  }
  closeOv('cart-ov');openOv('review-ov');
}

function toggleGiftField(){
  const t=document.getElementById('purchase-type')?.value;
  const f=document.getElementById('gift-field');
  if(f)f.style.display=t==='gift'?'block':'none';
}

function confirmOrder(){
  const{Session,OrderStore}=window.BMRP;
  const ptype=document.getElementById('purchase-type')?.value||'self';
  let giftSteam64='';
  if(ptype==='gift'){
    giftSteam64=(document.getElementById('gift-steam64')?.value||'').trim();
    if(!giftSteam64||!/^7656119\d{10}$/.test(giftSteam64)){
      showAlert('⚠️','Invalid Steam ID','Please enter a valid 17-digit Steam64 ID for the gift recipient.');return;
    }
  }
  const order=OrderStore.create(Session.username(),_cart,giftSteam64);
  window._pendingOrder=order;
  closeOv('review-ov');
  openStripeModal(order);
}

/* ── STRIPE PAYMENT ── */
let _stripeInstance=null,_stripeElements=null,_cardElement=null;

function openStripeModal(order){
  const body=document.getElementById('stripe-body');
  if(!body)return;
  const isGift=!!order.giftSteam64;
  body.innerHTML=`
    <div style="background:#0a0a0a;border:1px solid #161616;border-radius:3px;padding:10px 13px;margin-bottom:14px">
      <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#8B0000;text-transform:uppercase;margin-bottom:2px">Order ID</div>
      <div style="font-family:Oswald,sans-serif;font-size:14px;color:#7B68EE;letter-spacing:1px;font-weight:700">${order.id}</div>
      ${isGift?`<div style="font-size:11px;color:#C8A040;margin-top:4px">🎁 Gift for Steam64: ${order.giftSteam64}</div>`:''}
    </div>
    <div style="margin-bottom:14px">
      ${order.items.map(i=>`<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #111;font-size:12px"><span>${i.name}</span><span style="color:#7B68EE">$${i.price.toFixed(2)}</span></div>`).join('')}
      <div style="display:flex;justify-content:space-between;padding:10px 0 0;font-family:Oswald,sans-serif;font-size:16px;font-weight:700;color:#fff"><span>Total</span><span>$${order.total.toFixed(2)}</span></div>
    </div>
    <div style="font-family:Oswald,sans-serif;font-size:10px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:8px">Card Details</div>
    <div id="stripe-card-element" style="background:#080808;border:1px solid #222;border-radius:3px;padding:12px 14px;margin-bottom:8px;min-height:44px"></div>
    <div id="stripe-card-error" style="color:#ff6666;font-size:12px;min-height:18px;margin-bottom:10px"></div>
    <div style="background:#0d0d12;border:1px solid #1a1a2e;border-radius:3px;padding:10px 13px;font-size:11px;color:#555;line-height:1.6;margin-bottom:14px">
      🔒 <strong style="color:#888">Secured by Stripe.</strong> Your card information is encrypted and never stored on our servers.
    </div>`;

  // Mount Stripe card element
  if(window.Stripe){
    if(!_stripeInstance)_stripeInstance=window.Stripe(STRIPE_PK);
    _stripeElements=_stripeInstance.elements();
    _cardElement=_stripeElements.create('card',{
      style:{base:{color:'#fff',fontFamily:'"Roboto Condensed",sans-serif',fontSize:'15px',
        '::placeholder':{color:'#333'}},invalid:{color:'#ff6666'}},
      hidePostalCode:true
    });
    _cardElement.mount('#stripe-card-element');
    _cardElement.on('change',e=>{
      const err=document.getElementById('stripe-card-error');
      if(err)err.textContent=e.error?e.error.message:'';
    });
  } else {
    // Stripe.js not loaded — show manual placeholder
    const el=document.getElementById('stripe-card-element');
    if(el)el.innerHTML=`<div style="color:#555;font-size:12px;text-align:center;padding:8px">Stripe is loading... If this persists, check your internet connection.</div>`;
  }
  openOv('stripe-ov');
}

async function submitStripePayment(){
  const order=window._pendingOrder;if(!order)return;
  const btn=document.getElementById('stripe-pay-btn');
  const err=document.getElementById('stripe-card-error');

  if(!window.Stripe||!_stripeInstance||!_cardElement){
    // Demo mode — complete order without real charge (for testing before Stripe key is set)
    if(err)err.textContent='';
    if(btn){btn.textContent='Processing...';btn.disabled=true;}
    setTimeout(()=>{
      window.BMRP.OrderStore.complete(order.id);
      _cart=[];updateBadge();
      closeOv('stripe-ov');
      showConfirm(window.BMRP.OrderStore.get(order.id));
      window._pendingOrder=null;renderSupporters();
      if(btn){btn.textContent='Pay $'+order.total.toFixed(2)+' with Card';btn.disabled=false;}
    },1200);
    return;
  }

  if(btn){btn.textContent='Processing...';btn.disabled=true;}
  if(err)err.textContent='';

  try{
    // Create payment intent via Railway backend
    const res=await fetch(RAILWAY_URL+'/create-payment-intent',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({orderId:order.id,amount:Math.round(order.total*100),currency:'usd'})
    });
    if(!res.ok)throw new Error('Payment server error. Please try again.');
    const{clientSecret}=await res.json();

    const{paymentIntent,error}=await _stripeInstance.confirmCardPayment(clientSecret,{
      payment_method:{card:_cardElement}
    });

    if(error){
      if(err)err.textContent=error.message;
      if(btn){btn.textContent='Pay $'+order.total.toFixed(2)+' with Card';btn.disabled=false;}
      return;
    }

    if(paymentIntent.status==='succeeded'){
      window.BMRP.OrderStore.complete(order.id);
      _cart=[];updateBadge();
      closeOv('stripe-ov');
      showConfirm(window.BMRP.OrderStore.get(order.id));
      window._pendingOrder=null;renderSupporters();
    }
  }catch(ex){
    if(err)err.textContent=ex.message||'Payment failed. Please try again.';
    if(btn){btn.textContent='Pay $'+order.total.toFixed(2)+' with Card';btn.disabled=false;}
  }
}

function showConfirm(order){
  const body=document.getElementById('confirm-body');if(!body)return;
  const d=new Date(order.createdAt);
  body.innerHTML=`
    <div style="text-align:center;padding:6px 0 18px">
      <div style="font-size:42px;margin-bottom:9px">✅</div>
      <h3 style="font-family:Oswald,sans-serif;font-size:18px;color:#fff;letter-spacing:2px;text-transform:uppercase;margin-bottom:5px">Payment Successful!</h3>
      <p style="color:#555;font-size:12px;line-height:1.7">Your rank will be delivered within 24 hours. Check your purchase log in your account.</p>
      ${order.isGift?`<div style="margin-top:8px;background:#0f0a00;border:1px solid #C8A040;border-radius:3px;padding:8px 12px;font-size:12px;color:#C8A040">🎁 Gift delivery to Steam64: ${order.giftSteam64}</div>`:''}
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:14px">
      ${[['Order ID','<span style="color:#7B68EE;font-size:11px">'+order.id+'</span>'],['Account',order.username],['Date',d.toLocaleDateString()],['Payment','✓ Paid via Stripe'],['Status',order.orderStatus],['Delivery',order.deliveryStatus]].map(([l,v])=>`<div style="background:#0a0a0a;border:1px solid #161616;border-radius:3px;padding:10px 12px"><div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#8B0000;text-transform:uppercase;margin-bottom:2px">${l}</div><div style="font-family:Oswald,sans-serif;font-size:12px;color:#fff">${v}</div></div>`).join('')}
    </div>
    <div style="border-top:1px solid #1a1a1a;padding-top:11px;margin-bottom:12px">
      <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:7px">Items Purchased</div>
      ${order.items.map(i=>`<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #0f0f0f;font-size:12px"><span>${i.name}</span><span style="color:#7B68EE">$${i.price.toFixed(2)}</span></div>`).join('')}
      <div style="display:flex;justify-content:space-between;padding:9px 0 0;font-family:Oswald,sans-serif;font-size:16px;font-weight:700;color:#fff"><span>Total Paid</span><span>$${order.total.toFixed(2)}</span></div>
    </div>
    <div style="background:#0e0e0e;border-left:3px solid #7B68EE;padding:9px 12px;font-size:11px;color:#555;line-height:1.6;border-radius:2px">📋 Save your Order ID: <strong style="color:#fff">${order.id}</strong> — view it anytime in your account.</div>`;
  openOv('confirm-ov');
}

/* ── SUGGESTIONS ── */
function submitSuggestion(e){
  e?.preventDefault();
  const{Session,SuggestionStore}=window.BMRP;
  const s=Session.current();
  const text=(document.getElementById('sug-text')?.value||'').trim();
  const type=document.getElementById('sug-type')?.value||'suggestion';
  const m=document.getElementById('sug-msg');
  const show=(t,ok)=>{if(m){m.textContent=t;m.style.color=ok?'#2ecc71':'#ff6666';m.style.display='block';setTimeout(()=>m.style.display='none',4000);}};
  if(!text){show('Please enter your feedback.',false);return;}
  SuggestionStore.add(s?s.username:'Anonymous',text,type);
  show('✓ Submitted! Thank you.',true);
  const ti=document.getElementById('sug-text');if(ti)ti.value='';
  if(window.BMRP.Session.canAdmin()){renderAdminSuggestions();refreshAdminPanel();}
}

/* ── SUPPORTERS ── */
function renderSupporters(){
  const{SupporterStore}=window.BMRP;
  const top=SupporterStore.top(),recent=SupporterStore.recent();
  const tn=document.getElementById('top-name'),ta=document.getElementById('top-amount');
  if(tn)tn.textContent=top?top.username:'No top supporter yet';
  if(ta)ta.textContent=top?'Total: $'+top.total.toFixed(2):'Be the first to support BMRP';
  const rl=document.getElementById('recent-list');
  if(rl)rl.innerHTML=recent.length
    ?recent.map(e=>`<li style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #141414;font-size:12px;color:#D4D4D4"><span>${e.username}</span><span style="color:#7B68EE">$${e.amount.toFixed(2)}</span></li>`).join('')
    :'<li style="color:#2a2a2a;font-style:italic;font-size:11px">No purchases yet</li>';
}

/* ── SHOP TABS ── */
function shopTab(tab,btn){
  document.querySelectorAll('.shop-tab').forEach(t=>t.classList.remove('st-active'));
  document.querySelectorAll('.shop-pane').forEach(p=>p.style.display='none');
  const pane=document.getElementById('shop-'+tab);if(pane)pane.style.display='block';
  btn.classList.add('st-active');
}

/* ── ACCORDION ── */
function toggleAcc(id){document.getElementById(id)?.classList.toggle('acc-open');}

/* ── IMG SLOTS (admin only) ── */
function imgLoad(input,id){
  if(!window.BMRP.Session.canAdmin()){showAlert('🔒','Admin Only','Only admins can upload images.');input.value='';return;}
  const file=input.files[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=ev=>{
    const slot=document.getElementById(id);if(!slot)return;
    slot.querySelectorAll('.is-icon,.is-lbl,input[type=file]').forEach(el=>el.style.display='none');
    let img=slot.querySelector('img');
    if(!img){img=document.createElement('img');slot.appendChild(img);}
    img.src=ev.target.result;
    img.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:cover';
    const rm=slot.querySelector('.is-rm');if(rm)rm.style.display='block';
  };
  reader.readAsDataURL(file);
}
function imgClear(id,e){
  e?.stopPropagation();
  const slot=document.getElementById(id);if(!slot)return;
  slot.querySelectorAll('.is-icon,.is-lbl').forEach(el=>el.style.display='');
  const fi=slot.querySelector('input[type=file]');if(fi){fi.style.display='';fi.value='';}
  const img=slot.querySelector('img');if(img)img.remove();
  const rm=slot.querySelector('.is-rm');if(rm)rm.style.display='none';
}

/* ══════════════════════════════════════════════════
   ADMIN PANEL — FULLY LIVE, READS FRESH EVERY TIME
══════════════════════════════════════════════════ */
function initAdminPanel(){
  const{Session}=window.BMRP;
  const panel=document.getElementById('admin-float');if(!panel)return;
  if(Session.canAdmin()){
    panel.style.display='block';
    refreshAdminPanel();
  } else {
    panel.style.display='none';
  }
}

// This is called every time something changes — reads localStorage fresh
function refreshAdminPanel(){
  const{Session}=window.BMRP;
  if(!Session.canAdmin())return;
  renderAdminOrders();
  renderAdminStats();
  if(Session.isSuperAdmin()){
    const ss=document.getElementById('super-sec');if(ss)ss.style.display='block';
    renderUserTable();
    renderAdminSuggestions();
  }
}

function toggleAdmin(){
  const b=document.getElementById('admin-float-body'),a=document.getElementById('adm-arrow');
  if(!b)return;
  const isOpen=b.style.display!=='none';
  b.style.display=isOpen?'none':'block';
  if(a)a.textContent=isOpen?'▲':'▼';
  if(!isOpen)refreshAdminPanel(); // Refresh on open
}

function renderAdminStats(){
  const{OrderStore,OStatus,VisitorStore,UserStore}=window.BMRP;
  const all=OrderStore.all();
  const rev=all.filter(o=>o.orderStatus===OStatus.COMPLETED).reduce((s,o)=>s+o.total,0);
  setText('adm-s-orders',all.length);
  setText('adm-s-rev','$'+rev.toFixed(2));
  setText('adm-s-pending',all.filter(o=>o.orderStatus==='Pending').length);
  const ve=document.getElementById('adm-s-visitors');if(ve)ve.textContent=VisitorStore.count();
  const ue=document.getElementById('adm-s-users');if(ue)ue.textContent=Object.keys(UserStore.all()).length;
}

function renderAdminOrders(data){
  const{OrderStore}=window.BMRP;
  // Always read fresh from localStorage
  const orders=data||OrderStore.all();
  const tbody=document.getElementById('adm-tbody');if(!tbody)return;
  if(!orders.length){
    tbody.innerHTML='<tr><td colspan="8" style="text-align:center;color:#333;padding:16px;font-size:12px">No orders yet.</td></tr>';return;
  }
  tbody.innerHTML=orders.map(o=>`<tr onclick="admOpenOrder('${o.id}')" style="cursor:pointer">
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;color:#7B68EE;font-size:10px;letter-spacing:1px">${o.id}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f">${o.username}${o.isGift?'<br><span style="font-size:9px;color:#C8A040">🎁 Gift</span>':''}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-size:11px">${o.items.map(i=>i.name).join('<br>')}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-family:Oswald,sans-serif">$${o.total.toFixed(2)}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f"><span class="pill ${pillCls(o.orderStatus)}">${o.orderStatus}</span></td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f"><span class="pill ${payCls(o.paymentStatus)}">${o.paymentStatus}</span></td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f"><span class="pill ${delivCls(o.deliveryStatus)}">${o.deliveryStatus}</span></td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;color:#555;font-size:10px">${new Date(o.createdAt).toLocaleDateString()}</td>
  </tr>`).join('');
}

function admSearch(){renderAdminOrders(window.BMRP.OrderStore.search(document.getElementById('adm-search')?.value||''));}
function admFilter(){renderAdminOrders(window.BMRP.OrderStore.filter(document.getElementById('adm-filter')?.value||'all'));}

function admOpenOrder(id){
  const{OrderStore,Session}=window.BMRP;
  const o=OrderStore.get(id);if(!o)return;
  const t=document.getElementById('adm-order-title');if(t)t.textContent=o.id;
  const body=document.getElementById('adm-order-body');if(!body)return;
  const bs=(bg,col)=>`style="background:${bg};border:1px solid ${col};color:${col};font-family:Oswald,sans-serif;font-size:10px;letter-spacing:1px;text-transform:uppercase;padding:6px 11px;border-radius:2px;cursor:pointer;white-space:nowrap"`;
  body.innerHTML=`
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:14px">
      ${[['Order ID','<span style="color:#7B68EE;font-size:11px">'+o.id+'</span>'],['Account',o.username],['Steam64',o.steam64||'⚠️ Not set'],['Total','$'+o.total.toFixed(2)],['Type',o.isGift?'🎁 Gift to: '+o.giftSteam64:'Personal'],['Created',new Date(o.createdAt).toLocaleString()]].map(([l,v])=>`<div style="background:#0a0a0a;border:1px solid #161616;border-radius:3px;padding:10px 12px"><div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#8B0000;text-transform:uppercase;margin-bottom:2px">${l}</div><div style="font-family:Oswald,sans-serif;font-size:12px;color:#fff;word-break:break-all">${v}</div></div>`).join('')}
    </div>
    <div style="margin-bottom:14px;border-top:1px solid #1a1a1a;padding-top:11px">
      <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:7px">Items</div>
      ${o.items.map(i=>`<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #0f0f0f;font-size:12px"><span>${i.name}</span><span style="color:#7B68EE">$${i.price.toFixed(2)}</span></div>`).join('')}
    </div>
    <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:8px">Actions</div>
    <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px">
      <button onclick="admAct('${o.id}','pay','Payment Confirmed')" ${bs('#001426','#3498db')}>✅ Confirm Payment</button>
      <button onclick="admAct('${o.id}','order','Processing')" ${bs('#001426','#3498db')}>🔄 Processing</button>
      <button onclick="admComplete('${o.id}')" ${bs('#001a00','#2ecc71')}>🏆 Complete &amp; Deliver</button>
      <button onclick="admAct('${o.id}','order','Refunded')" ${bs('#14001a','#9b59b6')}>↩ Refunded</button>
      ${Session.isSuperAdmin()?`<button onclick="admAct('${o.id}','order','Failed')" ${bs('#1a0000','#e74c3c')}>✕ Failed</button>`:''}
    </div>
    <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;color:#555;text-transform:uppercase;margin-bottom:5px">Admin Notes</div>
    <textarea id="adm-notes-${o.id}" style="width:100%;background:#0a0a0a;border:1px solid #1e1e1e;border-radius:3px;padding:8px;color:#fff;font-size:12px;min-height:60px;outline:none;resize:vertical">${o.notes||''}</textarea>
    <button onclick="admSaveNotes('${o.id}')" style="background:#111;border:1px solid #252525;border-radius:2px;color:#777;font-family:Oswald,sans-serif;font-size:10px;letter-spacing:1px;text-transform:uppercase;padding:6px 11px;cursor:pointer;margin-top:7px">Save Notes</button>`;
  openOv('adm-order-ov');
}
function admAct(id,type,val){
  const p=type==='pay'?{paymentStatus:val}:{orderStatus:val};
  window.BMRP.OrderStore.update(id,p);
  refreshAdminPanel();closeOv('adm-order-ov');admToast('Updated.');
}
function admComplete(id){
  window.BMRP.OrderStore.complete(id);
  refreshAdminPanel();closeOv('adm-order-ov');admToast('✓ Order completed and delivered!');
}
function admSaveNotes(id){
  const el=document.getElementById('adm-notes-'+id);
  if(el)window.BMRP.OrderStore.update(id,{notes:el.value});admToast('Notes saved.');
}

// Gift code generation from admin panel
function admGenerateGiftCode(){
  const itemKey=document.getElementById('gc-item-key')?.value||'';
  const itemName=document.getElementById('gc-item-name')?.value||'';
  const{Session,GiftCodeStore}=window.BMRP;
  if(!itemKey||!itemName){admToast('Enter item key and name.');return;}
  const code=GiftCodeStore.generate(itemKey,itemName,Session.username());
  admToast('Code generated: '+code);
  renderGiftCodes();
  const inp=document.getElementById('gc-item-key');if(inp)inp.value='';
  const inp2=document.getElementById('gc-item-name');if(inp2)inp2.value='';
}

function renderGiftCodes(){
  const{GiftCodeStore}=window.BMRP;
  const codes=GiftCodeStore.all();
  const el=document.getElementById('adm-gift-codes');if(!el)return;
  if(!codes.length){el.innerHTML='<p style="color:#333;font-size:12px;padding:8px 0">No gift codes yet.</p>';return;}
  el.innerHTML='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:11px"><thead><tr>'+
    ['Code','Item','Created By','Status','Used By'].map(h=>`<th style="background:#0a0a0a;padding:7px 9px;text-align:left;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#555;border-bottom:1px solid #1f1f1f">${h}</th>`).join('')+
    '</tr></thead><tbody>'+
    codes.map(c=>`<tr>
      <td style="padding:6px 9px;border-bottom:1px solid #0f0f0f;font-family:monospace;color:#7B68EE;font-size:12px">${c.code}</td>
      <td style="padding:6px 9px;border-bottom:1px solid #0f0f0f">${c.itemName}</td>
      <td style="padding:6px 9px;border-bottom:1px solid #0f0f0f;color:#555">${c.createdBy}</td>
      <td style="padding:6px 9px;border-bottom:1px solid #0f0f0f"><span class="pill ${c.used?'pill-complete':'pill-pending'}">${c.used?'Used':'Active'}</span></td>
      <td style="padding:6px 9px;border-bottom:1px solid #0f0f0f;color:#555">${c.usedBy||'—'}</td>
    </tr>`).join('')+'</tbody></table></div>';
}

// Renders ALL registered accounts — reads fresh every call
function renderUserTable(){
  const{UserStore,ROLE_LABELS,ROLES}=window.BMRP;
  const users=Object.values(UserStore.all());
  const tbody=document.getElementById('adm-user-tbody');if(!tbody)return;
  if(!users.length){
    tbody.innerHTML='<tr><td colspan="6" style="text-align:center;color:#333;padding:16px;font-size:12px">No registered accounts yet.</td></tr>';return;
  }
  users.sort((a,b)=>new Date(b.joinDate)-new Date(a.joinDate));
  tbody.innerHTML=users.map(u=>`<tr>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-family:Oswald,sans-serif;color:#fff">${u.username}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-size:11px;color:#777">${u.ingame||'—'}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-size:10px;color:#333">${u.steam64||'—'}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f">
      <span style="background:rgba(139,0,0,0.2);border:1px solid #8B0000;color:#CC0000;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:1px;text-transform:uppercase;padding:2px 7px;border-radius:2px">${ROLE_LABELS[u.role]||'Player'}</span>
    </td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f;font-size:11px">${u.orderIds?.length||0}</td>
    <td style="padding:7px 9px;border-bottom:1px solid #0f0f0f">
      <select onchange="admSetRole('${u.username}',this.value)" style="background:#111;border:1px solid #222;border-radius:3px;color:#fff;font-size:11px;padding:3px 7px">
        ${Object.entries(ROLES).map(([k,v])=>`<option value="${v}" ${u.role===v?'selected':''}>${ROLE_LABELS[v]||k}</option>`).join('')}
      </select>
    </td>
  </tr>`).join('');
}
function admSetRole(username,role){
  window.BMRP.UserStore.update(username,{role:parseInt(role)});
  admToast('Role updated for '+username+'.');renderUserTable();
}

// Renders ALL suggestions — reads fresh every call
function renderAdminSuggestions(){
  const{SuggestionStore}=window.BMRP;
  const sug=SuggestionStore.all();
  const el=document.getElementById('adm-suggestions');if(!el)return;
  if(!sug.length){el.innerHTML='<p style="color:#333;font-size:12px;padding:8px 0">No suggestions yet.</p>';return;}
  el.innerHTML=sug.map(s=>`
    <div style="padding:10px;border-bottom:1px solid #111">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;flex-wrap:wrap">
        <span style="color:#8B0000;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:1px;text-transform:uppercase;background:rgba(139,0,0,0.15);padding:2px 7px;border-radius:2px">${s.type}</span>
        <span style="color:#555;font-size:10px">${s.username} — ${new Date(s.createdAt).toLocaleDateString()}</span>
        <span class="pill ${s.status==='Pending'?'pill-pending':s.status==='Done'?'pill-complete':'pill-failed'}">${s.status}</span>
      </div>
      <p style="color:#D4D4D4;line-height:1.5;margin-bottom:7px;font-size:12px">${s.text}</p>
      <div style="display:flex;gap:6px">
        <button onclick="window.BMRP.SuggestionStore.updateStatus(${s.id},'Done');renderAdminSuggestions()" style="background:none;border:1px solid #2ecc71;color:#2ecc71;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:1px;text-transform:uppercase;padding:3px 8px;border-radius:2px;cursor:pointer">✓ Done</button>
        <button onclick="window.BMRP.SuggestionStore.updateStatus(${s.id},'Dismissed');renderAdminSuggestions()" style="background:none;border:1px solid #555;color:#555;font-family:Oswald,sans-serif;font-size:9px;letter-spacing:1px;text-transform:uppercase;padding:3px 8px;border-radius:2px;cursor:pointer">Dismiss</button>
      </div>
    </div>`).join('');
}

function admToast(msg){
  let t=document.getElementById('adm-toast');
  if(!t){
    t=document.createElement('div');t.id='adm-toast';
    t.style.cssText='position:fixed;bottom:80px;left:50%;transform:translateX(-50%);background:#111;border:1px solid #7B68EE;border-radius:4px;padding:10px 18px;font-family:Oswald,sans-serif;font-size:11px;letter-spacing:1px;color:#fff;z-index:9999;transition:opacity .3s;pointer-events:none;white-space:nowrap';
    document.body.appendChild(t);
  }
  t.textContent=msg;t.style.opacity='1';
  setTimeout(()=>t.style.opacity='0',3000);
}

/* ── CONTENT EDITING (admin only) ── */
function initEditable(){
  const{Session,ROLES,ContentStore}=window.BMRP;
  if(!Session.canAdmin())return;
  document.querySelectorAll('[data-ck]').forEach(el=>{
    const key=el.dataset.ck,saved=ContentStore.get(key);
    if(saved)el.innerHTML=saved;
    el.contentEditable='true';
    el.style.outline='1px dashed rgba(139,0,0,0.3)';
    el.addEventListener('blur',()=>{
      if(Session.is(ROLES.OWNER)){ContentStore.set(key,el.innerHTML);}
      else{ContentStore.submitEdit(key,el.innerHTML,Session.username());admToast('Edit submitted for approval.');}
    });
  });
}

/* ── STAFF PROFILES ── */
const _profiles={
  mellow:{name:'Mellow',initial:'M',role:'Owner',bio:"Hello! I'm Mellow, the owner of BloodMoney RP. I'm a young Unturned developer and code editor who has had the opportunity to work on some of the most recognized servers in the Unturned community. Through that experience, I've gained knowledge in custom development, optimization, and server management.<br><br>My goal is to create a unique roleplay experience through original plugins, constant improvements, and a server that players can always enjoy.",responsibilities:'The Owner is responsible for the overall vision, development, and management of BloodMoney RP. They oversee server operations, lead the staff team, develop and maintain custom systems, and make final decisions on all major changes.',contact:'Reach Mellow through the Discord server for serious matters.'},
  opz:{name:'Opz Winston',initial:'O',role:'Co-Owner',bio:'Opz Winston is the Co-Owner of BloodMoney RP, working hand-in-hand with Mellow to bring the server vision to life.',responsibilities:'The Co-Owner assists the Owner in managing the server, overseeing major decisions, daily operations, and steps in whenever the Owner is unavailable.',contact:'Available through Discord for community matters.'},
  shark:{name:'Shark',initial:'S',role:'Server Director',bio:'Shark serves as the Server Director of BloodMoney RP, responsible for the overall direction of in-game systems.',responsibilities:'Oversees the staff team, enforces standards, manages administrative operations, and coordinates updates and events.',contact:'Contact Shark through official Discord support channels.'},
  harry:{name:'Harry',initial:'H',role:'Assistant Director',bio:'Harry supports the leadership team in keeping BloodMoney RP running smoothly day to day.',responsibilities:'Works alongside the Server Director assisting with staff management, handling reports, and ensuring policies are followed.',contact:'Contact Harry through official Discord support channels.'},
  jj:{name:'JJ',initial:'J',role:'Head Admin',bio:'JJ is the Head Admin on BloodMoney RP — responsive, fair, and dedicated to the community.',responsibilities:'Moderating in-game behavior, handling player reports, enforcing server rules, and leading the admin team.',contact:'Reach JJ through #support in the Discord server.'}
};
function showProfile(key){
  const p=_profiles[key];if(!p)return;
  const sl=document.getElementById('staff-list'),sp=document.getElementById('staff-profile');
  if(sl)sl.style.display='none';if(sp)sp.style.display='block';
  setText('p-avatar',p.initial);setText('p-name',p.name);setText('p-role',p.role);
  const pb=document.getElementById('p-body');
  if(pb)pb.innerHTML=`
    <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:3px;text-transform:uppercase;color:#444;border-bottom:1px solid #1a1a1a;padding-bottom:6px;margin-bottom:10px">About</div>
    <p style="color:#D4D4D4;line-height:1.75;font-size:14px;margin-bottom:22px">${p.bio}</p>
    <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:3px;text-transform:uppercase;color:#444;border-bottom:1px solid #1a1a1a;padding-bottom:6px;margin-bottom:10px">Responsibilities</div>
    <p style="color:#D4D4D4;line-height:1.75;font-size:14px;margin-bottom:22px">${p.responsibilities}</p>
    <div style="font-family:Oswald,sans-serif;font-size:9px;letter-spacing:3px;text-transform:uppercase;color:#444;border-bottom:1px solid #1a1a1a;padding-bottom:6px;margin-bottom:10px">Contact</div>
    <p style="color:#D4D4D4;line-height:1.75;font-size:14px">${p.contact}</p>`;
  window.scrollTo(0,0);
}
function closeProfile(){
  const sl=document.getElementById('staff-list'),sp=document.getElementById('staff-profile');
  if(sl)sl.style.display='block';if(sp)sp.style.display='none';window.scrollTo(0,0);
}

/* ── HELPERS ── */
function setText(id,val){const e=document.getElementById(id);if(e)e.textContent=val;}
function pillCls(s){return{'Pending':'pill-pending','Processing':'pill-processing','Completed':'pill-complete','Failed':'pill-failed','Refunded':'pill-refunded'}[s]||'pill-pending';}
function payCls(s){if(!s)return'pill-pending';if(s==='Paid')return'pill-complete';if(s.includes('Confirm')||s.includes('Verify'))return'pill-processing';return'pill-pending';}
function delivCls(s){return{'Queued':'pill-pending','Delivered':'pill-complete','Failed':'pill-failed','Manual Required':'pill-processing'}[s]||'pill-pending';}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded',()=>{
  if(window.BMRP){seedAdmin();}
  initScroll();initIP();initNav();applyNav();renderSupporters();initEditable();
  if(window.BMRP){const v=window.BMRP.VisitorStore.track();const el=document.getElementById('visitor-count');if(el)el.textContent=v.toLocaleString();}
});
